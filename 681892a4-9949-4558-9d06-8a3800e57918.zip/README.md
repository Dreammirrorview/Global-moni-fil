# Monipoint Futures & Network Payment System

## Owner
Olawale Abdul-Ganiyu  
Global Bank - Full Service Banking Platform

## Overview
A comprehensive payment system for Monipoint Futures and Network with full banking capabilities, including account management, payment processing, transaction tracking, and wallet address generation.

## Features

### ✅ Account Management
- Create new accounts with unique account numbers
- Edit account credit/balance
- Support for multiple banks (Monipoint, GTBank, Access Bank, First Bank, etc.)
- Automatic wallet address generation for each account

### ✅ Payment Processing
- Send payments to other banks and Monipoint accounts
- Receive payments from other banks and Monipoint accounts
- Real-time balance updates
- Transaction validation and error handling

### ✅ Transaction Tracking
- Complete transaction history
- Detailed transaction information including:
  - Transaction ID and Reference
  - Sender Name, Account Number, and Bank
  - Receiver Name, Account Number, and Bank
  - Amount and Currency
  - Date and Time
  - Transaction Status
  - Wallet Address
  - Transaction Type (Credit/Debit)

### ✅ Wallet Address Generation
- Unique wallet addresses for each account
- Transaction-specific wallet addresses
- Secure address generation system

## System Architecture

### Backend (Node.js/Express)
- **Database**: In-memory database simulation (can be replaced with MongoDB/PostgreSQL)
- **API**: RESTful API with full CRUD operations
- **Payment Service**: Complete payment processing logic
- **Server**: Express.js server on port 3000

### Frontend (HTML/CSS/JavaScript)
- **UI**: Modern, responsive interface
- **Forms**: Account creation, payment sending/receiving, credit editing
- **Dashboard**: Real-time statistics and overview
- **Transaction Display**: Detailed transaction history with all required fields

## API Endpoints

### Accounts
- `POST /api/accounts/create` - Create new account
- `GET /api/accounts` - Get all accounts
- `GET /api/accounts/balance/:accountNumber` - Get account balance
- `PUT /api/accounts/credit` - Edit account credit

### Payments
- `POST /api/payments/send` - Send payment
- `POST /api/payments/receive` - Receive payment

### Transactions
- `GET /api/transactions` - Get all transactions
- `GET /api/transactions/account/:accountNumber` - Get account transactions

### Wallets
- `POST /api/wallets/transaction` - Generate transaction wallet address

### Banks
- `GET /api/banks` - Get supported banks

## Transaction Details Structure

Each transaction contains complete information as requested:

```json
{
  "id": 1001,
  "reference": "TXN176887375034767",
  "senderName": "Olawale Abdul-Ganiyu",
  "senderAccount": "8012345678",
  "senderBank": "Monipoint",
  "receiverName": "John Doe",
  "receiverAccount": "80066042272",
  "receiverBank": "GTBank",
  "amount": 50000,
  "currency": "NGN",
  "type": "debit",
  "description": "Transfer to John Doe - GTBank",
  "receiverWalletAddress": "MP-80066042272-WALLET",
  "status": "completed",
  "createdAt": "2026-01-20T01:49:10.347Z"
}
```

## Getting Started

### Installation
```bash
cd backend
npm install
```

### Start Server
```bash
node server.js
```

### Access Application
Open your browser and navigate to: `http://localhost:3000`

## Supported Banks

- Monipoint
- Access Bank
- First Bank
- GTBank
- UBA
- Zenith Bank
- Kuda Bank
- Wema Bank
- Sterling Bank
- Fidelity Bank
- Union Bank
- Ecobank
- Polaris Bank
- Stanbic IBTC

## Testing

The system has been tested with the following scenarios:
1. ✅ Account creation with unique account numbers
2. ✅ Credit/balance editing functionality
3. ✅ Payment sending between accounts
4. ✅ Payment receiving from external banks
5. ✅ Transaction history tracking
6. ✅ Wallet address generation
7. ✅ Real-time balance updates
8. ✅ Transaction detail display with all required fields

## Security Features

- Input validation on all forms
- Balance checking before payments
- Transaction reference generation
- Unique account and wallet address generation
- Error handling and user notifications

## Technology Stack

### Backend
- Node.js
- Express.js
- CORS middleware

### Frontend
- HTML5
- CSS3 (Modern, responsive design)
- Vanilla JavaScript (ES6+)

## Live Demo

The payment system is currently running and accessible at:
**https://3000-60591b52-1aa7-4dcd-a94a-45a1b3319466.sandbox-service.public.prod.myninja.ai**

## Notes

- This is a complete payment system simulation
- In production, replace the in-memory database with a proper database (MongoDB, PostgreSQL, etc.)
- Implement proper authentication and authorization
- Add SSL/TLS encryption for production
- Integrate with actual banking APIs for real transactions
- Implement proper logging and monitoring

## Support

For issues or questions, please contact the system owner:
**Olawale Abdul-Ganiyu**  
**Global Bank - Monipoint Futures & Network**

---

© 2025 Monipoint Futures & Network Payment System. All rights reserved.