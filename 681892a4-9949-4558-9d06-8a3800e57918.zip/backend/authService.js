const crypto = require('crypto');

class AuthService {
    constructor() {
        this.users = [];
        this.sessions = {};
        this.ownerEmail = 'olawale@globalbank.com';
    }

    // Hash password
    hashPassword(password) {
        return crypto.createHash('sha256').update(password).digest('hex');
    }

    // Sign up new user (only owner)
    signUp(email, password, name, phone) {
        // Check if user already exists
        if (this.users.find(user => user.email === email)) {
            throw new Error('User already exists');
        }

        // Create new user
        const user = {
            id: Date.now(),
            email: email.toLowerCase(),
            password: this.hashPassword(password),
            name: name,
            phone: phone,
            role: email === this.ownerEmail ? 'owner' : 'user',
            createdAt: new Date().toISOString(),
            accountNumber: null,
            walletAddress: null
        };

        this.users.push(user);
        return {
            success: true,
            message: 'Account created successfully',
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
                role: user.role
            }
        };
    }

    // Login user
    login(email, password) {
        const user = this.users.find(user => user.email === email.toLowerCase());
        
        if (!user) {
            throw new Error('User not found');
        }

        if (user.password !== this.hashPassword(password)) {
            throw new Error('Invalid password');
        }

        // Create session
        const sessionToken = crypto.randomBytes(32).toString('hex');
        this.sessions[sessionToken] = {
            userId: user.id,
            email: user.email,
            role: user.role,
            createdAt: new Date().toISOString()
        };

        return {
            success: true,
            message: 'Login successful',
            token: sessionToken,
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
                role: user.role,
                accountNumber: user.accountNumber,
                walletAddress: user.walletAddress
            }
        };
    }

    // Verify session
    verifySession(token) {
        const session = this.sessions[token];
        
        if (!session) {
            throw new Error('Invalid session');
        }

        const user = this.users.find(user => user.id === session.userId);
        
        if (!user) {
            throw new Error('User not found');
        }

        return {
            success: true,
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
                role: user.role,
                accountNumber: user.accountNumber,
                walletAddress: user.walletAddress
            }
        };
    }

    // Logout
    logout(token) {
        delete this.sessions[token];
        return {
            success: true,
            message: 'Logout successful'
        };
    }

    // Forgot password - generate reset token
    forgotPassword(email) {
        const user = this.users.find(user => user.email === email.toLowerCase());
        
        if (!user) {
            throw new Error('User not found');
        }

        // Generate reset token
        const resetToken = crypto.randomBytes(32).toString('hex');
        user.resetToken = resetToken;
        user.resetTokenExpiry = new Date(Date.now() + 3600000).toISOString(); // 1 hour

        return {
            success: true,
            message: 'Password reset token generated',
            resetToken: resetToken,
            email: user.email
        };
    }

    // Reset password
    resetPassword(token, newPassword) {
        const user = this.users.find(user => 
            user.resetToken === token && 
            new Date(user.resetTokenExpiry) > new Date()
        );

        if (!user) {
            throw new Error('Invalid or expired reset token');
        }

        user.password = this.hashPassword(newPassword);
        delete user.resetToken;
        delete user.resetTokenExpiry;

        return {
            success: true,
            message: 'Password reset successful'
        };
    }

    // Generate account number for user
    generateAccountNumber(userId) {
        const user = this.users.find(user => user.id === userId);
        
        if (!user) {
            throw new Error('User not found');
        }

        if (user.accountNumber) {
            throw new Error('Account number already exists');
        }

        // Generate unique account number
        const prefix = "80";
        const randomDigits = Math.floor(Math.random() * 1000000000).toString().padStart(9, '0');
        const accountNumber = prefix + randomDigits.substring(0, 9);
        const walletAddress = `GB-${accountNumber}-WALLET`;

        user.accountNumber = accountNumber;
        user.walletAddress = walletAddress;

        return {
            success: true,
            message: 'Account number generated successfully',
            accountNumber: accountNumber,
            walletAddress: walletAddress
        };
    }

    // Get user by ID
    getUserById(userId) {
        const user = this.users.find(user => user.id === userId);
        
        if (!user) {
            throw new Error('User not found');
        }

        return {
            success: true,
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
                phone: user.phone,
                role: user.role,
                accountNumber: user.accountNumber,
                walletAddress: user.walletAddress
            }
        };
    }

    // Check if owner exists
    ownerExists() {
        return this.users.some(user => user.role === 'owner');
    }
}

module.exports = new AuthService();