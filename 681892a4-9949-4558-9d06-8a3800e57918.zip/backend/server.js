const express = require('express');
const cors = require('cors');
const paymentService = require('./paymentService');
const authService = require('./authService');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from frontend directory
app.use(express.static('../frontend'));

// API Routes

// Authentication Routes
app.post('/api/auth/signup', (req, res) => {
    try {
        const { email, password, name, phone } = req.body;
        const result = authService.signUp(email, password, name, phone);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

app.post('/api/auth/login', (req, res) => {
    try {
        const { email, password } = req.body;
        const result = authService.login(email, password);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

app.post('/api/auth/logout', (req, res) => {
    try {
        const { token } = req.body;
        const result = authService.logout(token);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

app.post('/api/auth/forgot-password', (req, res) => {
    try {
        const { email } = req.body;
        const result = authService.forgotPassword(email);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

app.post('/api/auth/reset-password', (req, res) => {
    try {
        const { token, newPassword } = req.body;
        const result = authService.resetPassword(token, newPassword);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

app.post('/api/auth/generate-account', (req, res) => {
    try {
        const { userId } = req.body;
        const result = authService.generateAccountNumber(userId);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

app.get('/api/auth/verify', (req, res) => {
    try {
        const token = req.headers.authorization;
        if (!token) {
            throw new Error('No token provided');
        }
        const result = authService.verifySession(token);
        res.json(result);
    } catch (error) {
        res.status(401).json({ success: false, message: error.message });
    }
});

app.get('/api/auth/owner-exists', (req, res) => {
    try {
        const exists = authService.ownerExists();
        res.json({ success: true, exists: exists });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Create Account
app.post('/api/accounts/create', (req, res) => {
    try {
        const { name, bankName } = req.body;
        const result = paymentService.createAccount(name, bankName);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Get All Accounts
app.get('/api/accounts', (req, res) => {
    try {
        const result = paymentService.getAllAccounts();
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Get Account Balance
app.get('/api/accounts/balance/:accountNumber', (req, res) => {
    try {
        const { accountNumber } = req.params;
        const result = paymentService.getBalance(accountNumber);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Edit Credit
app.put('/api/accounts/credit', (req, res) => {
    try {
        const { accountNumber, newBalance } = req.body;
        const result = paymentService.editCredit(accountNumber, newBalance);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Send Payment
app.post('/api/payments/send', (req, res) => {
    try {
        const { senderAccountNumber, receiverAccountNumber, receiverName, amount, receiverBank, senderBank } = req.body;
        const result = paymentService.sendPayment(
            senderAccountNumber,
            receiverAccountNumber,
            receiverName,
            amount,
            receiverBank,
            senderBank || "Monipoint"
        );
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Receive Payment
app.post('/api/payments/receive', (req, res) => {
    try {
        const { receiverAccountNumber, senderName, senderAccountNumber, amount, senderBank } = req.body;
        const result = paymentService.receivePayment(
            receiverAccountNumber,
            senderName,
            senderAccountNumber,
            amount,
            senderBank
        );
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Get Transaction History
app.get('/api/transactions/account/:accountNumber', (req, res) => {
    try {
        const { accountNumber } = req.params;
        const result = paymentService.getTransactionHistory(accountNumber);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Get All Transactions
app.get('/api/transactions', (req, res) => {
    try {
        const result = paymentService.getAllTransactions();
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Generate Transaction Wallet
app.post('/api/wallets/transaction', (req, res) => {
    try {
        const { accountNumber } = req.body;
        const result = paymentService.generateTransactionWallet(accountNumber);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Get Supported Banks
app.get('/api/banks', (req, res) => {
    try {
        const result = paymentService.getSupportedBanks();
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Health Check
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'Monipoint Payment System API is running' });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Monipoint Payment System Server running on port ${PORT}`);
    console.log(`Access the application at http://localhost:${PORT}`);
});