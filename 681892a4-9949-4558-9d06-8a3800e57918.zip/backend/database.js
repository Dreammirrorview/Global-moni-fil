// Database simulation for Monipoint Payment System
// In production, this would connect to a real database

class Database {
    constructor() {
        // Initialize with sample data
        this.accounts = [
            {
                id: 1,
                name: "Olawale Abdul-Ganiyu",
                accountNumber: "8012345678",
                bankName: "Monipoint",
                balance: 5000000.00,
                currency: "NGN",
                walletAddress: "MP-8012345678-WALLET",
                createdAt: new Date().toISOString()
            }
        ];
        
        this.transactions = [];
        this.transactionCounter = 1000;
    }

    // Account Management
    createAccount(name, bankName = "Monipoint") {
        const accountNumber = this.generateAccountNumber();
        const walletAddress = `MP-${accountNumber}-WALLET`;
        
        const account = {
            id: this.accounts.length + 1,
            name: name,
            accountNumber: accountNumber,
            bankName: bankName,
            balance: 0.00,
            currency: "NGN",
            walletAddress: walletAddress,
            createdAt: new Date().toISOString()
        };
        
        this.accounts.push(account);
        return account;
    }

    getAccountByNumber(accountNumber) {
        return this.accounts.find(acc => acc.accountNumber === accountNumber);
    }

    getAccountByWalletAddress(walletAddress) {
        return this.accounts.find(acc => acc.walletAddress === walletAddress);
    }

    getAllAccounts() {
        return this.accounts;
    }

    updateBalance(accountNumber, amount) {
        const account = this.getAccountByNumber(accountNumber);
        if (account) {
            account.balance += amount;
            return account;
        }
        return null;
    }

    editCredit(accountNumber, newBalance) {
        const account = this.getAccountByNumber(accountNumber);
        if (account) {
            account.balance = parseFloat(newBalance);
            return account;
        }
        return null;
    }

    // Transaction Management
    createTransaction(transactionData) {
        const transaction = {
            id: ++this.transactionCounter,
            reference: `TXN${Date.now()}${Math.floor(Math.random() * 1000)}`,
            ...transactionData,
            status: "completed",
            createdAt: new Date().toISOString()
        };
        
        this.transactions.push(transaction);
        return transaction;
    }

    getTransactionById(id) {
        return this.transactions.find(txn => txn.id === id);
    }

    getTransactionsByAccount(accountNumber) {
        return this.transactions.filter(txn => 
            txn.senderAccount === accountNumber || 
            txn.receiverAccount === accountNumber
        );
    }

    getAllTransactions() {
        return this.transactions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    // Utility Methods
    generateAccountNumber() {
        const prefix = "80";
        const randomDigits = Math.floor(Math.random() * 1000000000).toString().padStart(9, '0');
        return prefix + randomDigits.substring(0, 9);
    }

    generateWalletAddress() {
        return `MP-${this.generateAccountNumber()}-WALLET`;
    }
}

// Export singleton instance
module.exports = new Database();