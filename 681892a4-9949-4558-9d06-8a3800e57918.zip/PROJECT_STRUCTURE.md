# Monipoint Payment System - Project Structure

```
/workspace/
│
├── backend/
│   ├── database.js              # Database simulation with account and transaction management
│   ├── paymentService.js        # Core payment processing logic
│   ├── server.js                # Express.js server and API routes
│   └── package.json             # Backend dependencies
│
├── frontend/
│   ├── index.html               # Main HTML interface
│   ├── styles.css               # Styling and responsive design
│   └── app.js                   # Frontend JavaScript application logic
│
├── todo.md                      # Project task tracking (all tasks completed ✓)
├── README.md                    # Complete project documentation
└── PROJECT_STRUCTURE.md         # This file
```

## File Descriptions

### Backend Files

#### `database.js`
- Simulates database functionality
- Manages accounts array with account details
- Manages transactions array with complete transaction history
- Provides methods for:
  - Creating accounts with unique account numbers
  - Account lookups by number or wallet address
  - Balance updates and credit editing
  - Transaction creation and retrieval
  - Unique ID and wallet address generation

#### `paymentService.js`
- Core business logic for payment processing
- Handles all payment operations:
  - Account creation (with automatic wallet address generation)
  - Credit/balance editing
  - Payment sending (bank-to-bank, Monipoint-to-Monipoint)
  - Payment receiving
  - Transaction history retrieval
  - Transaction wallet address generation
- Validates all inputs
- Checks account balances before payments
- Creates detailed transaction records

#### `server.js`
- Express.js server configuration
- RESTful API endpoints for all operations:
  - Account management (create, read, update)
  - Payment processing (send, receive)
  - Transaction tracking
  - Wallet generation
  - Bank listing
- CORS enabled for cross-origin requests
- Serves static frontend files
- Runs on port 3000

#### `package.json`
- Node.js project configuration
- Dependencies: express, cors
- Scripts: start, dev (with nodemon)

### Frontend Files

#### `index.html`
- Complete user interface structure
- Navigation menu with sections:
  - Dashboard (overview and statistics)
  - Accounts (create, edit, view all)
  - Send Payment (form with all required fields)
  - Receive Payment (form with all required fields)
  - Wallet Addresses (generation and viewing)
  - Transactions (complete history)
- Semantic HTML structure
- Responsive design
- Forms with proper validation

#### `styles.css`
- Modern, professional styling
- Responsive design for all devices
- Features:
  - Gradient backgrounds and cards
  - Smooth animations and transitions
  - Color-coded transactions (credit/debit)
  - Mobile-friendly layout
  - Custom form styling
  - Dashboard statistics cards
  - Account and wallet displays

#### `app.js`
- Complete frontend application logic
- Functions:
  - Navigation between sections
  - API communication with backend
  - Form handling and validation
  - Real-time data updates
  - Transaction display formatting
  - Account and wallet listing
  - Notification system
  - Currency and date formatting
  - Error handling

## Key Features by Section

### Dashboard
- Total accounts count
- Total transactions count
- Total balance across all accounts
- Quick navigation buttons

### Accounts Section
- Create new account form (name, bank)
- Edit credit form (account number, new balance)
- Display all accounts with:
  - Account holder name
  - Formatted account number
  - Bank name
  - Current balance
  - Wallet address

### Send Payment Section
- Complete payment form with:
  - Sender account number
  - Sender bank selection
  - Receiver name
  - Receiver account number
  - Receiver bank selection
  - Amount input
- Real-time validation
- Success/error notifications
- Transaction receipt display with all details

### Receive Payment Section
- Complete receive form with:
  - Receiver account number
  - Sender name
  - Sender account number
  - Sender bank selection
  - Amount input
- Balance updates
- Transaction confirmation

### Wallet Addresses Section
- Generate unique transaction wallet address
- View all account wallet addresses
- Display account details with wallet

### Transactions Section
- Complete transaction history
- Each transaction displays:
  - Transaction ID and reference
  - Status indicator
  - Amount (color-coded by type)
  - Sender details (name, account, bank)
  - Receiver details (name, account, bank)
  - Date and time
  - Transaction type
  - Wallet address (if applicable)

## Data Flow

1. **Account Creation**
   - Frontend form → API POST /api/accounts/create → PaymentService → Database
   - Returns account with generated account number and wallet address

2. **Credit Editing**
   - Frontend form → API PUT /api/accounts/credit → PaymentService → Database
   - Updates account balance

3. **Send Payment**
   - Frontend form → API POST /api/payments/send → PaymentService
   - Validates sender balance
   - Deducts from sender
   - Credits receiver (if internal)
   - Creates transaction record
   - Returns transaction details

4. **Receive Payment**
   - Frontend form → API POST /api/payments/receive → PaymentService
   - Validates receiver account
   - Credits receiver account
   - Creates transaction record
   - Returns transaction details

5. **Transaction History**
   - Frontend request → API GET /api/transactions → PaymentService → Database
   - Returns all transactions sorted by date

## Transaction Details

Each transaction includes exactly the fields requested:
- ✅ Sender Name
- ✅ Sender Account Number
- ✅ Sender Bank (Monipoint)
- ✅ Receiver Name
- ✅ Receiver Account Number
- ✅ Receiver Bank
- ✅ Amount
- ✅ Date and Time
- ✅ Transaction Type (Credit/Debit)
- ✅ Wallet Address (for Monipoint accounts)
- ✅ Transaction Reference/ID
- ✅ Status

## Security Considerations

- Input validation on all forms
- Balance verification before payments
- Unique transaction references
- Error handling and user feedback
- CORS configuration
- Sanitized data storage

## Scalability Notes

- In-memory database can be replaced with:
  - MongoDB for document storage
  - PostgreSQL for relational data
  - Redis for caching
- API can be scaled with load balancers
- Frontend can be deployed to CDN
- WebSocket support for real-time updates

## Integration Points

- Bank APIs for actual transfers
- Payment gateways for external processing
- SMS/Email notifications
- Accounting systems
- Reporting tools