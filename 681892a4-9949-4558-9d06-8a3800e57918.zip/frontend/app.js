// Monipoint Payment System - Frontend Application

const API_BASE_URL = 'http://localhost:3000/api';

// Global state
let currentSection = 'dashboard';
let allAccounts = [];
let allTransactions = [];

// Initialize application - called after authentication
function initializeApp() {
    initializeEventListeners();
    loadDashboardData();
    loadAccounts();
    loadTransactions();
}

// Initialize event listeners
function initializeEventListeners() {
    // Navigation
    document.querySelectorAll('nav button').forEach(button => {
        button.addEventListener('click', function() {
            const sectionId = this.textContent.toLowerCase().replace(' ', '-');
            showSection(sectionId);
        });
    });

    // Forms
    document.getElementById('create-account-form').addEventListener('submit', handleCreateAccount);
    document.getElementById('edit-credit-form').addEventListener('submit', handleEditCredit);
    document.getElementById('send-payment-form').addEventListener('submit', handleSendPayment);
    document.getElementById('receive-payment-form').addEventListener('submit', handleReceivePayment);
    document.getElementById('generate-wallet-form').addEventListener('submit', handleGenerateWallet);
}

// Show section
function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });

    // Remove active class from nav buttons
    document.querySelectorAll('nav button').forEach(button => {
        button.classList.remove('active');
    });

    // Show selected section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
        currentSection = sectionId;
    }

    // Add active class to corresponding nav button
    const navButtons = document.querySelectorAll('nav button');
    navButtons.forEach(button => {
        if (button.textContent.toLowerCase().replace(' ', '-') === sectionId) {
            button.classList.add('active');
        }
    });

    // Refresh data when switching sections
    if (sectionId === 'dashboard') {
        loadDashboardData();
    } else if (sectionId === 'accounts') {
        loadAccounts();
    } else if (sectionId === 'transactions') {
        loadTransactions();
    } else if (sectionId === 'wallets') {
        loadAccounts(); // To show wallet addresses
    }
}

// API Helper Functions
async function apiRequest(endpoint, method = 'GET', data = null) {
    try {
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            }
        };

        if (data) {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
        const result = await response.json();

        if (!result.success) {
            throw new Error(result.message || 'Request failed');
        }

        return result;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Load Dashboard Data
async function loadDashboardData() {
    try {
        const accountsResponse = await apiRequest('/accounts');
        const transactionsResponse = await apiRequest('/transactions');

        const accounts = accountsResponse.accounts || [];
        const transactions = transactionsResponse.transactions || [];

        const totalBalance = accounts.reduce((sum, account) => sum + account.balance, 0);

        document.getElementById('total-accounts').textContent = accounts.length;
        document.getElementById('total-transactions').textContent = transactions.length;
        document.getElementById('total-balance').textContent = formatCurrency(totalBalance);

    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

// Load Accounts
async function loadAccounts() {
    try {
        const response = await apiRequest('/accounts');
        allAccounts = response.accounts || [];
        displayAccounts(allAccounts);
    } catch (error) {
        console.error('Error loading accounts:', error);
        showNotification('Error loading accounts', 'error');
    }
}

// Display Accounts
function displayAccounts(accounts) {
    const container = document.getElementById('accounts-list');
    const walletContainer = document.getElementById('wallet-list');

    if (accounts.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #666;">No accounts found. Create your first account above.</p>';
        if (walletContainer) {
            walletContainer.innerHTML = '<p style="text-align: center; color: #666;">No wallet addresses available.</p>';
        }
        return;
    }

    // Display in accounts section
    container.innerHTML = accounts.map(account => `
        <div class="account-card">
            <div class="account-name">${account.name}</div>
            <div class="account-number">${formatAccountNumber(account.accountNumber)}</div>
            <div class="account-bank">${account.bankName}</div>
            <div class="account-balance">${formatCurrency(account.balance)}</div>
            <div class="wallet-address">${account.walletAddress}</div>
        </div>
    `).join('');

    // Display in wallets section
    if (walletContainer) {
        walletContainer.innerHTML = accounts.map(account => `
            <div class="wallet-display">
                <h3>${account.name}</h3>
                <div class="address">${account.walletAddress}</div>
                <p>Account: ${formatAccountNumber(account.accountNumber)}</p>
                <p>Bank: ${account.bankName}</p>
                <p>Balance: ${formatCurrency(account.balance)}</p>
            </div>
        `).join('');
    }
}

// Handle Create Account
async function handleCreateAccount(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await apiRequest('/accounts/create', 'POST', data);
        showNotification(response.message, 'success');
        event.target.reset();
        loadAccounts();
        loadDashboardData();
    } catch (error) {
        showNotification(error.message, 'error');
    }
}

// Handle Edit Credit
async function handleEditCredit(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await apiRequest('/accounts/credit', 'PUT', data);
        showNotification(response.message, 'success');
        event.target.reset();
        loadAccounts();
        loadDashboardData();
    } catch (error) {
        showNotification(error.message, 'error');
    }
}

// Handle Send Payment
async function handleSendPayment(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await apiRequest('/payments/send', 'POST', data);
        showPaymentResult('send-payment-result', response);
        event.target.reset();
        loadAccounts();
        loadDashboardData();
        loadTransactions();
    } catch (error) {
        showNotification(error.message, 'error');
    }
}

// Handle Receive Payment
async function handleReceivePayment(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await apiRequest('/payments/receive', 'POST', data);
        showPaymentResult('receive-payment-result', response);
        event.target.reset();
        loadAccounts();
        loadDashboardData();
        loadTransactions();
    } catch (error) {
        showNotification(error.message, 'error');
    }
}

// Show Payment Result
function showPaymentResult(containerId, response) {
    const container = document.getElementById(containerId);
    const transaction = response.transaction;

    container.innerHTML = `
        <div class="card" style="border-left: 5px solid #00cc66; margin-top: 20px;">
            <h2 style="color: #00cc66;">${response.message}</h2>
            <div class="transaction-item ${transaction.type}">
                <div class="transaction-header">
                    <div>
                        <div class="transaction-id">Transaction ID: ${transaction.reference}</div>
                        <div style="margin-top: 5px; color: #666;">Status: <span class="transaction-status completed">${transaction.status}</span></div>
                    </div>
                    <div class="transaction-amount">${formatCurrency(transaction.amount)}</div>
                </div>
                <div class="transaction-details">
                    <div class="transaction-detail">
                        <label>Sender Name:</label>
                        <span>${transaction.senderName}</span>
                    </div>
                    <div class="transaction-detail">
                        <label>Sender Account:</label>
                        <span>${formatAccountNumber(transaction.senderAccount)}</span>
                    </div>
                    <div class="transaction-detail">
                        <label>Sender Bank:</label>
                        <span>${transaction.senderBank}</span>
                    </div>
                    <div class="transaction-detail">
                        <label>Receiver Name:</label>
                        <span>${transaction.receiverName}</span>
                    </div>
                    <div class="transaction-detail">
                        <label>Receiver Account:</label>
                        <span>${formatAccountNumber(transaction.receiverAccount)}</span>
                    </div>
                    <div class="transaction-detail">
                        <label>Receiver Bank:</label>
                        <span>${transaction.receiverBank}</span>
                    </div>
                    <div class="transaction-detail">
                        <label>Date & Time:</label>
                        <span>${formatDateTime(transaction.createdAt)}</span>
                    </div>
                    <div class="transaction-detail">
                        <label>Type:</label>
                        <span style="text-transform: uppercase; font-weight: 700;">${transaction.type}</span>
                    </div>
                </div>
                ${transaction.receiverWalletAddress ? `
                <div style="margin-top: 15px; padding: 10px; background-color: #f0f0f0; border-radius: 5px;">
                    <label style="color: #666;">Wallet Address:</label>
                    <span style="font-family: monospace; font-weight: 600;">${transaction.receiverWalletAddress}</span>
                </div>
                ` : ''}
            </div>
        </div>
    `;
    container.style.display = 'block';
}

// Handle Generate Wallet
async function handleGenerateWallet(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await apiRequest('/wallets/transaction', 'POST', data);
        showWalletResult(response);
        event.target.reset();
    } catch (error) {
        showNotification(error.message, 'error');
    }
}

// Show Wallet Result
function showWalletResult(response) {
    const container = document.getElementById('wallet-result');

    container.innerHTML = `
        <div class="wallet-display">
            <h3>Transaction Wallet Address Generated</h3>
            <div class="address">${response.transactionWallet}</div>
            <p>Account: ${formatAccountNumber(response.account.accountNumber)}</p>
            <p>Account Holder: ${response.account.name}</p>
            <p>Bank: ${response.account.bankName}</p>
        </div>
    `;
    container.style.display = 'block';
}

// Load Transactions
async function loadTransactions() {
    try {
        const response = await apiRequest('/transactions');
        allTransactions = response.transactions || [];
        displayTransactions(allTransactions);
    } catch (error) {
        console.error('Error loading transactions:', error);
        showNotification('Error loading transactions', 'error');
    }
}

// Display Transactions
function displayTransactions(transactions) {
    const container = document.getElementById('transactions-list');

    if (transactions.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #666;">No transactions found.</p>';
        return;
    }

    container.innerHTML = transactions.map(transaction => `
        <div class="transaction-item ${transaction.type}">
            <div class="transaction-header">
                <div>
                    <div class="transaction-id">Reference: ${transaction.reference}</div>
                    <div style="margin-top: 5px; color: #666;">Status: <span class="transaction-status completed">${transaction.status}</span></div>
                </div>
                <div class="transaction-amount">${formatCurrency(transaction.amount)}</div>
            </div>
            <div class="transaction-details">
                <div class="transaction-detail">
                    <label>Sender Name:</label>
                    <span>${transaction.senderName}</span>
                </div>
                <div class="transaction-detail">
                    <label>Sender Account:</label>
                    <span>${formatAccountNumber(transaction.senderAccount)}</span>
                </div>
                <div class="transaction-detail">
                    <label>Sender Bank:</label>
                    <span>${transaction.senderBank}</span>
                </div>
                <div class="transaction-detail">
                    <label>Receiver Name:</label>
                    <span>${transaction.receiverName}</span>
                </div>
                <div class="transaction-detail">
                    <label>Receiver Account:</label>
                    <span>${formatAccountNumber(transaction.receiverAccount)}</span>
                </div>
                <div class="transaction-detail">
                    <label>Receiver Bank:</label>
                    <span>${transaction.receiverBank}</span>
                </div>
                <div class="transaction-detail">
                    <label>Date & Time:</label>
                    <span>${formatDateTime(transaction.createdAt)}</span>
                </div>
                <div class="transaction-detail">
                    <label>Type:</label>
                    <span style="text-transform: uppercase; font-weight: 700;">${transaction.type}</span>
                </div>
            </div>
            ${transaction.receiverWalletAddress ? `
            <div style="margin-top: 15px; padding: 10px; background-color: #f0f0f0; border-radius: 5px;">
                <label style="color: #666;">Wallet Address:</label>
                <span style="font-family: monospace; font-weight: 600;">${transaction.receiverWalletAddress}</span>
            </div>
            ` : ''}
        </div>
    `).join('');
}

// Utility Functions
function formatCurrency(amount) {
    return '₦' + parseFloat(amount).toLocaleString('en-NG', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function formatAccountNumber(accountNumber) {
    if (!accountNumber) return 'N/A';
    // Format: 8012345678 -> 8012 3456 78
    if (accountNumber.length === 10) {
        return accountNumber.replace(/(\d{4})(\d{4})(\d{2})/, '$1 $2 $3');
    }
    return accountNumber;
}

function formatDateTime(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleString('en-NG', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    });
}

function showNotification(message, type) {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());

    // Create new notification
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;

    // Insert at the top of the main content
    const main = document.querySelector('main');
    main.insertBefore(notification, main.firstChild);

    // Auto-remove after 5 seconds
    setTimeout(() => {
        notification.remove();
    }, 5000);
}