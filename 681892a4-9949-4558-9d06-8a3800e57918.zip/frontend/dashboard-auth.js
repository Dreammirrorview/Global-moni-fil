// Global Bank - Dashboard Authentication

const API_BASE_URL = 'http://localhost:3000/api';
let currentUser = null;
let authToken = null;

// Initialize dashboard authentication
document.addEventListener('DOMContentLoaded', function() {
    checkAuthentication();
});

// Check if user is authenticated
async function checkAuthentication() {
    authToken = localStorage.getItem('authToken');
    const userStr = localStorage.getItem('currentUser');
    
    if (!authToken || !userStr) {
        // Redirect to cover page
        window.location.href = 'cover.html';
        return;
    }

    try {
        // Verify token with server
        const response = await fetch(`${API_BASE_URL}/auth/verify`, {
            headers: {
                'Authorization': authToken
            }
        });
        
        const result = await response.json();
        
        if (!result.success) {
            // Token invalid, redirect to login
            logout();
            return;
        }

        currentUser = result.user;
        updateUserDisplay();
        
        // Initialize the main app
        if (typeof initializeApp === 'function') {
            initializeApp();
        }
    } catch (error) {
        console.error('Authentication error:', error);
        logout();
    }
}

// Update user display in header
function updateUserDisplay() {
    if (currentUser) {
        document.getElementById('user-name').textContent = `Welcome, ${currentUser.name}`;
        
        if (currentUser.accountNumber) {
            document.getElementById('user-account').textContent = 
                `Account: ${formatAccountNumber(currentUser.accountNumber)}`;
        } else {
            document.getElementById('user-account').textContent = 'Account: Not generated yet';
        }
    }
}

// Handle logout
function handleLogout() {
    if (confirm('Are you sure you want to logout?')) {
        logout();
    }
}

// Logout function
async function logout() {
    try {
        if (authToken) {
            await fetch(`${API_BASE_URL}/auth/logout`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ token: authToken })
            });
        }
    } catch (error) {
        console.error('Logout error:', error);
    }

    // Clear local storage
    localStorage.removeItem('authToken');
    localStorage.removeItem('currentUser');
    
    // Redirect to cover page
    window.location.href = 'cover.html';
}

// Format account number
function formatAccountNumber(accountNumber) {
    if (!accountNumber) return 'N/A';
    if (accountNumber.length === 10) {
        return accountNumber.replace(/(\d{4})(\d{4})(\d{2})/, '$1 $2 $3');
    }
    return accountNumber;
}

// Get current user
function getCurrentUser() {
    return currentUser;
}

// Get auth token
function getAuthToken() {
    return authToken;
}