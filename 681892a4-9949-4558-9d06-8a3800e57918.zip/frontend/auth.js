// Global Bank - Authentication System

const API_BASE_URL = 'http://localhost:3000/api';
let currentUser = null;
let authToken = null;

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    checkExistingOwner();
    checkExistingSession();
});

// Check if owner already exists
async function checkExistingOwner() {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/owner-exists`);
        const result = await response.json();
        
        if (!result.exists) {
            // Show signup tab if no owner exists
            showAuthTab('signup');
            showNotification('Please create the owner account', 'success');
        }
    } catch (error) {
        console.error('Error checking owner:', error);
    }
}

// Check for existing session
async function checkExistingSession() {
    const token = localStorage.getItem('authToken');
    if (token) {
        try {
            const response = await fetch(`${API_BASE_URL}/auth/verify`, {
                headers: {
                    'Authorization': token
                }
            });
            const result = await response.json();
            
            if (result.success) {
                currentUser = result.user;
                authToken = token;
                // Redirect to dashboard
                window.location.href = 'index.html';
            }
        } catch (error) {
            localStorage.removeItem('authToken');
        }
    }
}

// Show authentication tab
function showAuthTab(tabName) {
    // Hide all forms
    document.querySelectorAll('.auth-form').forEach(form => {
        form.classList.remove('active');
    });

    // Remove active class from tabs
    document.querySelectorAll('.auth-tab').forEach(tab => {
        tab.classList.remove('active');
    });

    // Show selected form and activate tab
    document.getElementById(`${tabName}-form`).classList.add('active');
    
    const tabs = document.querySelectorAll('.auth-tab');
    tabs.forEach(tab => {
        if (tab.textContent.toLowerCase().includes(tabName) || 
            (tabName === 'forgot' && tab.textContent.toLowerCase().includes('forgot'))) {
            tab.classList.add('active');
        }
    });

    // Hide notification and account generated
    document.getElementById('notification').style.display = 'none';
    document.getElementById('account-generated').style.display = 'none';
}

// Handle login
async function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        const result = await response.json();

        if (result.success) {
            currentUser = result.user;
            authToken = result.token;
            localStorage.setItem('authToken', authToken);
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            
            // Generate account number if not exists
            if (!currentUser.accountNumber) {
                await generateAccountNumber(result.user.id);
            } else {
                showNotification('Login successful! Redirecting...', 'success');
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1500);
            }
        } else {
            showNotification(result.message, 'error');
        }
    } catch (error) {
        showNotification('Login failed. Please try again.', 'error');
    }
}

// Handle signup
async function handleSignup(event) {
    event.preventDefault();
    
    const name = document.getElementById('signup-name').value;
    const email = document.getElementById('signup-email').value;
    const phone = document.getElementById('signup-phone').value;
    const password = document.getElementById('signup-password').value;

    try {
        const response = await fetch(`${API_BASE_URL}/auth/signup`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, email, phone, password })
        });

        const result = await response.json();

        if (result.success) {
            currentUser = result.user;
            showNotification('Account created successfully!', 'success');
            
            // Auto-generate account number
            await generateAccountNumber(result.user.id);
        } else {
            showNotification(result.message, 'error');
        }
    } catch (error) {
        showNotification('Signup failed. Please try again.', 'error');
    }
}

// Handle forgot password
async function handleForgotPassword(event) {
    event.preventDefault();
    
    const email = document.getElementById('forgot-email').value;

    try {
        const response = await fetch(`${API_BASE_URL}/auth/forgot-password`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email })
        });

        const result = await response.json();

        if (result.success) {
            showNotification(`Password reset token: ${result.resetToken}`, 'success');
            showNotification('Use this token to reset your password', 'success');
        } else {
            showNotification(result.message, 'error');
        }
    } catch (error) {
        showNotification('Failed to send reset link. Please try again.', 'error');
    }
}

// Generate account number
async function generateAccountNumber(userId) {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/generate-account`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ userId })
        });

        const result = await response.json();

        if (result.success) {
            // Update current user with account details
            currentUser.accountNumber = result.accountNumber;
            currentUser.walletAddress = result.walletAddress;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));

            // Show account generated message
            document.getElementById('generated-account-number').textContent = 
                formatAccountNumber(result.accountNumber);
            document.getElementById('generated-wallet-address').textContent = 
                result.walletAddress;
            document.getElementById('account-generated').style.display = 'block';
            
            // Hide all forms
            document.querySelectorAll('.auth-form').forEach(form => {
                form.classList.remove('active');
            });

            showNotification('Account number generated successfully!', 'success');
        } else {
            showNotification(result.message, 'error');
        }
    } catch (error) {
        showNotification('Failed to generate account number. Please try again.', 'error');
    }
}

// Go to dashboard
function goToDashboard() {
    window.location.href = 'index.html';
}

// Show notification
function showNotification(message, type) {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.className = `notification ${type}`;
    notification.style.display = 'block';

    setTimeout(() => {
        notification.style.display = 'none';
    }, 5000);
}

// Format account number
function formatAccountNumber(accountNumber) {
    if (!accountNumber) return 'N/A';
    if (accountNumber.length === 10) {
        return accountNumber.replace(/(\d{4})(\d{4})(\d{2})/, '$1 $2 $3');
    }
    return accountNumber;
}