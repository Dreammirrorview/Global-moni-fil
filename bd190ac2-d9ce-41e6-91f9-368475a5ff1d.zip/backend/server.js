const express = require('express');
const cors = require('cors');
const paymentService = require('./paymentService');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from frontend directory
app.use(express.static('../frontend'));

// API Routes

// Create Account
app.post('/api/accounts/create', (req, res) => {
    try {
        const { name, bankName } = req.body;
        const result = paymentService.createAccount(name, bankName);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Get All Accounts
app.get('/api/accounts', (req, res) => {
    try {
        const result = paymentService.getAllAccounts();
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Get Account Balance
app.get('/api/accounts/balance/:accountNumber', (req, res) => {
    try {
        const { accountNumber } = req.params;
        const result = paymentService.getBalance(accountNumber);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Edit Credit
app.put('/api/accounts/credit', (req, res) => {
    try {
        const { accountNumber, newBalance } = req.body;
        const result = paymentService.editCredit(accountNumber, newBalance);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Send Payment
app.post('/api/payments/send', (req, res) => {
    try {
        const { senderAccountNumber, receiverAccountNumber, receiverName, amount, receiverBank, senderBank } = req.body;
        const result = paymentService.sendPayment(
            senderAccountNumber,
            receiverAccountNumber,
            receiverName,
            amount,
            receiverBank,
            senderBank || "Monipoint"
        );
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Receive Payment
app.post('/api/payments/receive', (req, res) => {
    try {
        const { receiverAccountNumber, senderName, senderAccountNumber, amount, senderBank } = req.body;
        const result = paymentService.receivePayment(
            receiverAccountNumber,
            senderName,
            senderAccountNumber,
            amount,
            senderBank
        );
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Get Transaction History
app.get('/api/transactions/account/:accountNumber', (req, res) => {
    try {
        const { accountNumber } = req.params;
        const result = paymentService.getTransactionHistory(accountNumber);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Get All Transactions
app.get('/api/transactions', (req, res) => {
    try {
        const result = paymentService.getAllTransactions();
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Generate Transaction Wallet
app.post('/api/wallets/transaction', (req, res) => {
    try {
        const { accountNumber } = req.body;
        const result = paymentService.generateTransactionWallet(accountNumber);
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Get Supported Banks
app.get('/api/banks', (req, res) => {
    try {
        const result = paymentService.getSupportedBanks();
        res.json(result);
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
});

// Health Check
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'Monipoint Payment System API is running' });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Monipoint Payment System Server running on port ${PORT}`);
    console.log(`Access the application at http://localhost:${PORT}`);
});