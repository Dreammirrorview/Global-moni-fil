const database = require('./database');

class PaymentService {
    constructor() {
        this.supportedBanks = [
            "Monipoint",
            "Access Bank",
            "First Bank",
            "GTBank",
            "UBA",
            "Zenith Bank",
            "Kuda Bank",
            "Wema Bank",
            "Sterling Bank",
            "Fidelity Bank",
            "Union Bank",
            "Ecobank",
            "Polaris Bank",
            "Stanbic IBTC"
        ];
    }

    // Create new account with wallet address
    createAccount(name, bankName = "Monipoint") {
        if (!name || name.trim() === "") {
            throw new Error("Account name is required");
        }

        const account = database.createAccount(name.trim(), bankName);
        return {
            success: true,
            message: "Account created successfully",
            account: account
        };
    }

    // Edit account credit/balance
    editCredit(accountNumber, newBalance) {
        if (!accountNumber || accountNumber.trim() === "") {
            throw new Error("Account number is required");
        }

        if (newBalance === undefined || newBalance === null || newBalance === "") {
            throw new Error("New balance is required");
        }

        const balance = parseFloat(newBalance);
        if (isNaN(balance) || balance < 0) {
            throw new Error("Invalid balance amount");
        }

        const account = database.editCredit(accountNumber.trim(), balance);
        if (!account) {
            throw new Error("Account not found");
        }

        return {
            success: true,
            message: "Credit updated successfully",
            account: account
        };
    }

    // Send payment to another bank or Monipoint
    sendPayment(senderAccountNumber, receiverAccountNumber, receiverName, amount, receiverBank, senderBank = "Monipoint") {
        // Validation
        if (!senderAccountNumber || !receiverAccountNumber || !receiverName || !amount || !receiverBank) {
            throw new Error("All payment details are required");
        }

        const amountValue = parseFloat(amount);
        if (isNaN(amountValue) || amountValue <= 0) {
            throw new Error("Invalid amount");
        }

        // Check sender account
        const senderAccount = database.getAccountByNumber(senderAccountNumber);
        if (!senderAccount) {
            throw new Error("Sender account not found");
        }

        // Check if sender has sufficient balance
        if (senderAccount.balance < amountValue) {
            throw new Error("Insufficient balance");
        }

        // Check if receiver exists in our system
        let receiverAccount = database.getAccountByNumber(receiverAccountNumber);
        
        // Generate transaction details
        const transactionData = {
            senderName: senderAccount.name,
            senderAccount: senderAccountNumber,
            senderBank: senderBank,
            receiverName: receiverName,
            receiverAccount: receiverAccountNumber,
            receiverBank: receiverBank,
            amount: amountValue,
            currency: "NGN",
            type: "debit",
            description: `Transfer to ${receiverName} - ${receiverBank}`
        };

        // Deduct from sender
        database.updateBalance(senderAccountNumber, -amountValue);

        // If receiver is in our system, credit their account
        if (receiverAccount) {
            database.updateBalance(receiverAccountNumber, amountValue);
            transactionData.receiverWalletAddress = receiverAccount.walletAddress;
        } else {
            // External bank transfer - just create the transaction
            transactionData.receiverWalletAddress = "EXTERNAL";
        }

        // Create transaction record
        const transaction = database.createTransaction(transactionData);

        return {
            success: true,
            message: "Payment sent successfully",
            transaction: transaction,
            newBalance: senderAccount.balance - amountValue
        };
    }

    // Receive payment from another bank or Monipoint
    receivePayment(receiverAccountNumber, senderName, senderAccountNumber, amount, senderBank) {
        // Validation
        if (!receiverAccountNumber || !senderName || !senderAccountNumber || !amount || !senderBank) {
            throw new Error("All payment details are required");
        }

        const amountValue = parseFloat(amount);
        if (isNaN(amountValue) || amountValue <= 0) {
            throw new Error("Invalid amount");
        }

        // Check receiver account
        const receiverAccount = database.getAccountByNumber(receiverAccountNumber);
        if (!receiverAccount) {
            throw new Error("Receiver account not found");
        }

        // Generate transaction details
        const transactionData = {
            senderName: senderName,
            senderAccount: senderAccountNumber,
            senderBank: senderBank,
            receiverName: receiverAccount.name,
            receiverAccount: receiverAccountNumber,
            receiverBank: "Monipoint",
            amount: amountValue,
            currency: "NGN",
            type: "credit",
            description: `Received from ${senderName} - ${senderBank}`,
            receiverWalletAddress: receiverAccount.walletAddress
        };

        // Credit receiver account
        database.updateBalance(receiverAccountNumber, amountValue);

        // Create transaction record
        const transaction = database.createTransaction(transactionData);

        return {
            success: true,
            message: "Payment received successfully",
            transaction: transaction,
            newBalance: receiverAccount.balance + amountValue
        };
    }

    // Get account balance
    getBalance(accountNumber) {
        const account = database.getAccountByNumber(accountNumber);
        if (!account) {
            throw new Error("Account not found");
        }

        return {
            success: true,
            account: account
        };
    }

    // Get transaction history
    getTransactionHistory(accountNumber) {
        const transactions = database.getTransactionsByAccount(accountNumber);
        
        return {
            success: true,
            transactions: transactions,
            totalTransactions: transactions.length
        };
    }

    // Get all transactions (admin view)
    getAllTransactions() {
        const transactions = database.getAllTransactions();
        
        return {
            success: true,
            transactions: transactions,
            totalTransactions: transactions.length
        };
    }

    // Get all accounts (admin view)
    getAllAccounts() {
        const accounts = database.getAllAccounts();
        
        return {
            success: true,
            accounts: accounts,
            totalAccounts: accounts.length
        };
    }

    // Generate unique wallet address for transaction
    generateTransactionWallet(accountNumber) {
        const account = database.getAccountByNumber(accountNumber);
        if (!account) {
            throw new Error("Account not found");
        }

        const timestamp = Date.now();
        const randomCode = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
        const transactionWallet = `MP-${account.accountNumber}-TXN-${timestamp}-${randomCode}`;

        return {
            success: true,
            transactionWallet: transactionWallet,
            accountNumber: accountNumber,
            account: account
        };
    }

    // Get supported banks
    getSupportedBanks() {
        return {
            success: true,
            banks: this.supportedBanks
        };
    }
}

module.exports = new PaymentService();